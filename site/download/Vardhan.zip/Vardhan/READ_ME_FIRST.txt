Vardhan - see the downside before you invest

1. Double-click Vardhan.exe (keep the assets and data folders next to it).
2. If Windows warns you: More info -> Run anyway.
3. Click "Try the demo".

Optional on-device AI: install Ollama (ollama.com), run: ollama pull llama3.2:3b
Then Settings & AI -> On-device AI -> Test connection.

Code: https://github.com/Stanvi09/Vardhan
An education project, not investment advice.
